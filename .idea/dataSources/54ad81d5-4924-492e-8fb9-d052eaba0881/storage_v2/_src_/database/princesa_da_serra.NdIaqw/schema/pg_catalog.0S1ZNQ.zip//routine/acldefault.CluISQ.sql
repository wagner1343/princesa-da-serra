create function acldefault("char", oid)
  returns aclitem[]
language internal
as $$
acldefault_sql
$$;

comment on function acldefault(char, oid)
is 'TODO';

