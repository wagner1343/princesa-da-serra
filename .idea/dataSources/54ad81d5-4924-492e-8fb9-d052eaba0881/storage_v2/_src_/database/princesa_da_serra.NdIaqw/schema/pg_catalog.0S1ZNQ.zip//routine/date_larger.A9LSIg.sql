create function date_larger(date, date)
  returns date
language internal
as $$
date_larger
$$;

comment on function date_larger(date, date)
is 'larger of two';

