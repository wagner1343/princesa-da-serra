create function box_contain(box, box)
  returns boolean
language internal
as $$
box_contain
$$;

comment on function box_contain(box, box)
is 'implementation of @> operator';

