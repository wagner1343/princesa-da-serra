create function bttidcmp(tid, tid)
  returns integer
language internal
as $$
bttidcmp
$$;

comment on function bttidcmp(tid, tid)
is 'less-equal-greater';

