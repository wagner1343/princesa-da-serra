create function asin(double precision)
  returns double precision
language internal
as $$
dasin
$$;

comment on function asin(float8)
is 'arcsine';

