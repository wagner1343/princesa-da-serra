create function count()
  returns bigint
language internal
as $$
aggregate_dummy
$$;

comment on function count()
is 'number of input rows';

