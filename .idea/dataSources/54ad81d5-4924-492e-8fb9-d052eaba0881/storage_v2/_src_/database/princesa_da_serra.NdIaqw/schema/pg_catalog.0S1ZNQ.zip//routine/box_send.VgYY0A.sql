create function box_send(box)
  returns bytea
language internal
as $$
box_send
$$;

comment on function box_send(box)
is 'I/O';

