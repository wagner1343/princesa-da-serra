create function btabstimecmp(abstime, abstime)
  returns integer
language internal
as $$
btabstimecmp
$$;

comment on function btabstimecmp(abstime, abstime)
is 'less-equal-greater';

