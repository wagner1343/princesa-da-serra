create function bttintervalcmp(tinterval, tinterval)
  returns integer
language internal
as $$
bttintervalcmp
$$;

comment on function bttintervalcmp(tinterval, tinterval)
is 'less-equal-greater';

