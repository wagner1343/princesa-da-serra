create function abstimegt(abstime, abstime)
  returns boolean
language internal
as $$
abstimegt
$$;

comment on function abstimegt(abstime, abstime)
is 'implementation of > operator';

