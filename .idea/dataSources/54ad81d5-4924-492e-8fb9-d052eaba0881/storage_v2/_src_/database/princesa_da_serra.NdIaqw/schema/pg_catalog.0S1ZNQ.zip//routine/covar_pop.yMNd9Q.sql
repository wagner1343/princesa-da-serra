create function covar_pop(double precision, double precision)
  returns double precision
language internal
as $$
aggregate_dummy
$$;

comment on function covar_pop(float8, float8)
is 'population covariance';

