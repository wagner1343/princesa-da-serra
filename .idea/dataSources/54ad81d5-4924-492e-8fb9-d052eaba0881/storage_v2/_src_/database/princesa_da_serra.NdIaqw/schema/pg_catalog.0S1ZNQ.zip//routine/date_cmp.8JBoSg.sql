create function date_cmp(date, date)
  returns integer
language internal
as $$
date_cmp
$$;

comment on function date_cmp(date, date)
is 'less-equal-greater';

