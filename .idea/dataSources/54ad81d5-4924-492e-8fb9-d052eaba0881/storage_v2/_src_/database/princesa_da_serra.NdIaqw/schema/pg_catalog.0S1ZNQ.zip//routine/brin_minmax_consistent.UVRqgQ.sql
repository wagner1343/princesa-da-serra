create function brin_minmax_consistent(internal, internal, internal)
  returns boolean
language internal
as $$
brin_minmax_consistent
$$;

comment on function brin_minmax_consistent(internal, internal, internal)
is 'BRIN minmax support';

