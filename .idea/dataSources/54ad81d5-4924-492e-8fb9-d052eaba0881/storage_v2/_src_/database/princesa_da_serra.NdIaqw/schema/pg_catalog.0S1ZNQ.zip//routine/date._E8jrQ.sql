create function date(timestamp with time zone)
  returns date
language internal
as $$
timestamptz_date
$$;

comment on function date(abstime)
is 'convert abstime to date';

