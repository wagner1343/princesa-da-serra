create function box_left(box, box)
  returns boolean
language internal
as $$
box_left
$$;

comment on function box_left(box, box)
is 'implementation of << operator';

