create function abstimein(cstring)
  returns abstime
language internal
as $$
abstimein
$$;

comment on function abstimein(cstring)
is 'I/O';

