create function boolout(boolean)
  returns cstring
language internal
as $$
boolout
$$;

comment on function boolout(bool)
is 'I/O';

