create function bit_send(bit)
  returns bytea
language internal
as $$
bit_send
$$;

comment on function bit_send(bit)
is 'I/O';

