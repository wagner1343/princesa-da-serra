create function close_sb(lseg, box)
  returns point
language internal
as $$
close_sb
$$;

comment on function close_sb(lseg, box)
is 'implementation of ## operator';

