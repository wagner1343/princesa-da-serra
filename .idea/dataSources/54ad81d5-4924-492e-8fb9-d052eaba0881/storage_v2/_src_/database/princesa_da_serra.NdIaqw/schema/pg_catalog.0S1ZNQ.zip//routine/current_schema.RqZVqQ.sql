create function "current_schema"()
  returns name
language internal
as $$
current_schema
$$;

comment on function "current_schema"()
is 'current schema name';

