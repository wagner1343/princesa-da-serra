create function avg(bigint)
  returns numeric
language internal
as $$
aggregate_dummy
$$;

comment on function avg(interval)
is 'the average (arithmetic mean) as interval of all interval values';

