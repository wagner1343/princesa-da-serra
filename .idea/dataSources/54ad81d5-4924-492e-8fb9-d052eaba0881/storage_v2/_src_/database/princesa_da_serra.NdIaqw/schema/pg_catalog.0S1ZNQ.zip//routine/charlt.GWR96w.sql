create function charlt("char", "char")
  returns boolean
language internal
as $$
charlt
$$;

comment on function charlt(char, char)
is 'implementation of < operator';

