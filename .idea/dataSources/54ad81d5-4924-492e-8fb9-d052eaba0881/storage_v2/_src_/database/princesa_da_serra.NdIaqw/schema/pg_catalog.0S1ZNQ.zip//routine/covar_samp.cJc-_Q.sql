create function covar_samp(double precision, double precision)
  returns double precision
language internal
as $$
aggregate_dummy
$$;

comment on function covar_samp(float8, float8)
is 'sample covariance';

