create function abstimeeq(abstime, abstime)
  returns boolean
language internal
as $$
abstimeeq
$$;

comment on function abstimeeq(abstime, abstime)
is 'implementation of = operator';

