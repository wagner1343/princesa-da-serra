create function byteage(bytea, bytea)
  returns boolean
language internal
as $$
byteage
$$;

comment on function byteage(bytea, bytea)
is 'implementation of >= operator';

