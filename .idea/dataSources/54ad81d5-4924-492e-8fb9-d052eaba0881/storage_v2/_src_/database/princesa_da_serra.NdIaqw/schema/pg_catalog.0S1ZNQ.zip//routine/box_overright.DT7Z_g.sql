create function box_overright(box, box)
  returns boolean
language internal
as $$
box_overright
$$;

comment on function box_overright(box, box)
is 'implementation of &> operator';

