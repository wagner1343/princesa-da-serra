create function cosd(double precision)
  returns double precision
language internal
as $$
dcosd
$$;

comment on function cosd(float8)
is 'cosine, degrees';

