create function bpchareq(character, character)
  returns boolean
language internal
as $$
bpchareq
$$;

comment on function bpchareq(bpchar, bpchar)
is 'implementation of = operator';

