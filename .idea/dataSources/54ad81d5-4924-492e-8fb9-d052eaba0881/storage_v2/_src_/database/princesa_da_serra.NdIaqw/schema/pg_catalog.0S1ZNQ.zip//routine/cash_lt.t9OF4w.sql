create function cash_lt(money, money)
  returns boolean
language internal
as $$
cash_lt
$$;

comment on function cash_lt(money, money)
is 'implementation of < operator';

