create function bpchar_smaller(character, character)
  returns character
language internal
as $$
bpchar_smaller
$$;

comment on function bpchar_smaller(bpchar, bpchar)
is 'smaller of two';

