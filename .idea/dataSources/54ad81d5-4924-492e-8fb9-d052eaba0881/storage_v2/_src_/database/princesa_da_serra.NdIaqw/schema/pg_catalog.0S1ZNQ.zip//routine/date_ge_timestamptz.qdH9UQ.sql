create function date_ge_timestamptz(date, timestamp with time zone)
  returns boolean
language internal
as $$
date_ge_timestamptz
$$;

comment on function date_ge_timestamptz(date, timestamptz)
is 'implementation of >= operator';

