create function abstimelt(abstime, abstime)
  returns boolean
language internal
as $$
abstimelt
$$;

comment on function abstimelt(abstime, abstime)
is 'implementation of < operator';

