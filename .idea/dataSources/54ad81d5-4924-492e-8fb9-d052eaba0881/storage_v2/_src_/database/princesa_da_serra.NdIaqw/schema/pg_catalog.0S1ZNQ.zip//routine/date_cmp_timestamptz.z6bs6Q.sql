create function date_cmp_timestamptz(date, timestamp with time zone)
  returns integer
language internal
as $$
date_cmp_timestamptz
$$;

comment on function date_cmp_timestamptz(date, timestamptz)
is 'less-equal-greater';

