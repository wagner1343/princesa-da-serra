create function cos(double precision)
  returns double precision
language internal
as $$
dcos
$$;

comment on function cos(float8)
is 'cosine';

