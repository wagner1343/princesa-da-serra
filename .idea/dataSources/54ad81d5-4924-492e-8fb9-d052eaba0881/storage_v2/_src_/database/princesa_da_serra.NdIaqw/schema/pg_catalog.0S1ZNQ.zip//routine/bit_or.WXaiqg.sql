create function bit_or(smallint)
  returns smallint
language internal
as $$
aggregate_dummy
$$;

comment on function bit_or(int4)
is 'bitwise-or integer aggregate';

