create function bpchar_pattern_le(character, character)
  returns boolean
language internal
as $$
bpchar_pattern_le
$$;

comment on function bpchar_pattern_le(bpchar, bpchar)
is 'implementation of ~<=~ operator';

