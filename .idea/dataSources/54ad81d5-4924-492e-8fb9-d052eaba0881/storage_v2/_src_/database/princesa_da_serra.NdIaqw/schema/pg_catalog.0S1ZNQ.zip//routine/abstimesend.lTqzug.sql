create function abstimesend(abstime)
  returns bytea
language internal
as $$
abstimesend
$$;

comment on function abstimesend(abstime)
is 'I/O';

