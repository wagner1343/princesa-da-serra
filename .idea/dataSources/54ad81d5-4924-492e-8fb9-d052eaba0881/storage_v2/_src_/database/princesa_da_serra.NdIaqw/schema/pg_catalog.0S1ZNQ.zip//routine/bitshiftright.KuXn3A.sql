create function bitshiftright(bit, integer)
  returns bit
language internal
as $$
bitshiftright
$$;

comment on function bitshiftright(bit, int4)
is 'implementation of >> operator';

