create function byteasend(bytea)
  returns bytea
language internal
as $$
byteasend
$$;

comment on function byteasend(bytea)
is 'I/O';

