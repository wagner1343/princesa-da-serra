create function btrecordcmp(record, record)
  returns integer
language internal
as $$
btrecordcmp
$$;

comment on function btrecordcmp(record, record)
is 'less-equal-greater';

