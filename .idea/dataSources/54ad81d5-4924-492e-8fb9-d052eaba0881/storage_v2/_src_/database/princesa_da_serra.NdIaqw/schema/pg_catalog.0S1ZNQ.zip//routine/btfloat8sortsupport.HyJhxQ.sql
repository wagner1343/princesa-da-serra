create function btfloat8sortsupport(internal)
  returns void
language internal
as $$
btfloat8sortsupport
$$;

comment on function btfloat8sortsupport(internal)
is 'sort support';

