create function bool_and(boolean)
  returns boolean
language internal
as $$
aggregate_dummy
$$;

comment on function bool_and(bool)
is 'boolean-and aggregate';

